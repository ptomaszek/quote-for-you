TODO:
 - fonts locally
 - background images as an option
 - cats and other pickable stuff in background

 TODO if the plugin succeeds:
 - fetch 10 quotes to assert new ones will be shown when offline
 - keep a bucket of 10 new quotes in local storage
 - remember ids of 10 last quotes to avoid duplicates (maybe this has no sense and the check could become a performance issue)
 - image of " in the background of the quote
